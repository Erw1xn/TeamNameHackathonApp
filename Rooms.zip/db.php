<?php
$db = mysqli_connect(
    'sql102.infinityfree.com',  // MYSQL HOSTNAME
    'if0_41822986',              // MYSQL USERNAME
    '020923Erwin',               // MYSQL PASSWORD (yung nasa dashboard mo)
    'if0_41822986_schooldb'      // MYSQL DATABASE NAME
);

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}
?>